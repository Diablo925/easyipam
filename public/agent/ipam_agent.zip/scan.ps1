$configPath = "C:\Program Files\IPAM-Agent\config.json"

if (-not (Test-Path $configPath)) {
    Write-Error "Config-fil ikke fundet: $configPath"
    exit
}

$config = Get-Content $configPath | ConvertFrom-Json
$debug = $config.debug
$apiKey = $config.api_key
$customerId = $config.customer_id
$ipamServer = $config.ipam_server

# Hent ekstra systemoplysninger
$hostname = $env:COMPUTERNAME
$agent_version = "1.5"
$os_info = (Get-CimInstance -ClassName Win32_OperatingSystem).Caption

# Sti til sidste scanning
$lastScanPath = "C:\Program Files\IPAM-Agent\last_scan_output.txt"
$previousHash = ""

if ((Test-Path $lastScanPath) -and (-not $debug)) {
    $previousHash = Get-FileHash -Path $lastScanPath -Algorithm SHA256 | Select-Object -ExpandProperty Hash
}

# Sæt sti til Nmap
$nmapPath = "C:\Program Files\IPAM-Agent\nmap.exe"
if (-not (Test-Path $nmapPath)) {
    Write-Error "Nmap ikke fundet: $nmapPath"
    exit
}

# Hent ranges fra serveren
$baseUrl = $ipamServer -replace "/upload_scan\.php", ""
$getRangesUrl = "$baseUrl/get_ranges_api.php?customer_id=$customerId&api_key=$apiKey"
$ranges = Invoke-RestMethod -Uri $getRangesUrl -Method Get

foreach ($range in $ranges) {
    Write-Output "Scanner $range"
    $scanOutput = & "$nmapPath" -F $range
    $scanOutputString = $scanOutput -join "`n"

    $scanOutputString | Out-File -FilePath $lastScanPath -Encoding utf8

    $currentHash = Get-FileHash -Path $lastScanPath -Algorithm SHA256 | Select-Object -ExpandProperty Hash

    if ($debug -or ($currentHash -ne $previousHash)) {
$payload = @{
    api_key       = $apiKey
    customer_id   = $customerId
    scan_data     = $scanOutputString
    machine_name  = $hostname  # <== ændret her
    agent_version = $agent_version
    os_info       = $os_info
} | ConvertTo-Json -Compress

        Invoke-RestMethod -Uri $ipamServer -Method Post -Body $payload -ContentType 'application/json'
        Write-Output "Upload OK"

    } else {
        Write-Output "Ingen ændringer i scanning – springer upload over"
    }
}

Write-Output "Færdig"
