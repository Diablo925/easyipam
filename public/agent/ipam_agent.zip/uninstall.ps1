$taskName = "IPAM Nmap Probe"

if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    Write-Output "Task '$taskName' blev fjernet."
} else {
    Write-Output "Task '$taskName' blev ikke fundet."
}
