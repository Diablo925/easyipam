# IPAM Windows Agent - Network Scanning with Nmap + UniFi Integration (Multi-Site)
# Version: 1.7
# Requires: PowerShell 5+, jq.exe (for Windows), nmap.exe

$ConfigFile = "C:\Program Files\IPAM-Agent\config.json"
$UnifiConfig = "C:\Program Files\IPAM-Agent\unifi-config.json"
$NmapPath = "C:\Program Files\IPAM-Agent\nmap.exe"

# --- Load config.json ---
if (!(Test-Path $ConfigFile)) {
    Write-Error "Missing configuration file: $ConfigFile"
    exit 1
}

$Config = Get-Content $ConfigFile | ConvertFrom-Json
$API_KEY = $Config.api_key
$CUSTOMER_ID = $Config.customer_id
$IPAM_SERVER = $Config.ipam_server
$DEBUG = $Config.debug

if ([string]::IsNullOrWhiteSpace($API_KEY) -or [string]::IsNullOrWhiteSpace($CUSTOMER_ID) -or [string]::IsNullOrWhiteSpace($IPAM_SERVER)) {
    Write-Error "Invalid configuration values."
    exit 1
}

$HOSTNAME = $env:COMPUTERNAME
$AGENT_VERSION = "1.7"
$OS_INFO = "$($env:OS) $([System.Environment]::OSVersion.Version)"

# ==============================================================
# UniFi Integration (Multi-Site)
# ==============================================================
$UnifiData = @()

if (Test-Path $UnifiConfig) {
    $UConfig = Get-Content $UnifiConfig | ConvertFrom-Json
    if ($UConfig.enabled -eq $true) {
        $Sites = $UConfig.sites
        foreach ($Site in $Sites) {
            if ([string]::IsNullOrWhiteSpace($Site.controller_ip) -or [string]::IsNullOrWhiteSpace($Site.api_key) -or [string]::IsNullOrWhiteSpace($Site.site_id)) {
                continue
            }

            $ControllerIP = $Site.controller_ip
            $ControllerPort = $Site.controller_port
            $APIKeyUnifi = $Site.api_key
            $SiteID = $Site.site_id

            Write-Host "Fetching UniFi data from $ControllerIP:$ControllerPort (Site: $SiteID)..."

            # --- Clients ---
            $ClientsURL = "https://$ControllerIP`:$ControllerPort/proxy/network/integration/v1/sites/$SiteID/clients"
            try {
                $Clients = Invoke-RestMethod -Uri $ClientsURL -Headers @{
                    "X-API-KEY" = $APIKeyUnifi
                    "Accept"    = "application/json"
                } -Method GET -SkipCertificateCheck
            } catch {
                Write-Warning "Failed to fetch clients for $SiteID"
                continue
            }

            foreach ($Client in $Clients.data) {
                if (![string]::IsNullOrWhiteSpace($Client.ipAddress)) {
                    $Description = "$($Client.name) [$($Client.macAddress)]"
                    $UnifiData += [PSCustomObject]@{
                        ip          = $Client.ipAddress
                        description = $Description
                        device_type = ""
                    }
                }
            }

            # --- Devices ---
            $DevicesURL = "https://$ControllerIP`:$ControllerPort/proxy/network/integration/v1/sites/$SiteID/devices"
            try {
                $Devices = Invoke-RestMethod -Uri $DevicesURL -Headers @{
                    "X-API-KEY" = $APIKeyUnifi
                    "Accept"    = "application/json"
                } -Method GET -SkipCertificateCheck
            } catch {
                Write-Warning "Failed to fetch devices for $SiteID"
                continue
            }

            foreach ($Device in $Devices.data) {
                $IP = $Device.ipAddress
                $Name = $Device.name
                $MAC = $Device.macAddress
                $Model = $Device.model

                # --- UDM/Gateway Fix ---
                if ($IP -and $IP -notmatch '^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1]))') {
                    if ($Model -match "UDM" -or $Name -match "Gateway") {
                        $IP = $ControllerIP
                    }
                }

                if ($IP) {
                    $Description = "$Name [$MAC]"
                    $UnifiData += [PSCustomObject]@{
                        ip          = $IP
                        description = $Description
                        device_type = $Model
                    }
                }
            }
        }
    }
}

# ==============================================================
# Nmap Scan from IPAM ranges
# ==============================================================
$BaseURL = $IPAM_SERVER -replace "/upload_scan\.php$", ""
$RangesURL = "$BaseURL/get_ranges_api.php?customer_id=$CUSTOMER_ID&api_key=$API_KEY"

try {
    $RangesResponse = Invoke-RestMethod -Uri $RangesURL -Method GET
    $Ranges = $RangesResponse.ranges | Where-Object { $_ -and $_ -ne "null" }
} catch {
    Write-Error "Failed to fetch IP ranges from IPAM"
    exit 1
}

if (-not $Ranges) {
    Write-Warning "No valid ranges found for customer."
    exit 0
}

$ScanOutput = ""
foreach ($Range in $Ranges) {
    Write-Host "Scanning $Range..."
    $ScanOutput += & "$NmapPath" -F $Range
}

# ==============================================================
# Prepare JSON payload
# ==============================================================
$Payload = @{
    api_key       = $API_KEY
    customer_id   = $CUSTOMER_ID
    scan_data     = $ScanOutput
    machine_name  = $HOSTNAME
    agent_version = $AGENT_VERSION
    os_info       = $OS_INFO
    unifi_data    = $UnifiData
} | ConvertTo-Json -Depth 5

# ==============================================================
# Send to IPAM
# ==============================================================
Invoke-RestMethod -Uri $IPAM_SERVER -Method POST -ContentType "application/json" -Body $Payload -SkipCertificateCheck

Write-Host "Scan (including UniFi data if available) uploaded to IPAM log."
