# === Konfiguration ===
$ScriptPath = "C:\Program Files\IPAM-Agent\scan.ps1"
$TaskName = "IPAM Nmap Probe"

# Opret Task Scheduler action
$Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File `"$ScriptPath`""

# Trigger: ugentlig scanning mandag kl. 09:00
$Trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At 9am

# Kør som SYSTEM med højeste rettigheder
$Principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest

# Registrer opgaven
Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal

Write-Output "Scheduled Task '$TaskName' oprettet."